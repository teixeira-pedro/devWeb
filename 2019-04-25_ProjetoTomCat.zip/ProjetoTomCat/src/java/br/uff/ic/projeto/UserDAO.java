/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.uff.ic.projeto;

//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.Statement;
//import java.sql.ResultSet;
import java.sql.*;

/**
 *
 * @author ProfessorK
 */
public class UserDAO {

    static Connection currentCon = null;
    static ResultSet rs = null;

    public static UserBean login(UserBean bean) {
        //preparing some objects for connection 
        Statement stmt = null;
        String cpf = bean.getCPF();
        String senha = bean.getSenha();
        
        // TO DO
        // dependendo do que chegou use CPF/senha ou senhaPIN
        String searchQuery
                = "select * from users where cpf='"
                + cpf
                + "' AND senha='"
                + senha
                + "'"; 
        
        
        String senhaPIN = bean.getSenhaPIN();
        if (senhaPIN != null && !"".equals(senhaPIN)){
            searchQuery
                = "select * from users where senhaPIN='"+ senhaPIN + "'"; 
        }
                    

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("seu cpf eh " + cpf);
        System.out.println("sua senha eh " + senha);
        System.out.println("sua senhaPIN eh " + senhaPIN);
        System.out.println("Query: " + searchQuery);
        try {
            //connect to DB 
            Class.forName("com.mysql.jdbc.Driver");
            currentCon = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projeto", "root", "");
            // projeto eh o nome do banco
            
            
            /* TESTE
                PreparedStatement ps = con
                    .prepareStatement("INSERT INTO `users` (`acesso`, `cpf`, `senha`, `nome`, `admin`, `email`) VALUES " +
                    "(now(), 'teste', '123', 'Jose', 1, 'jose@ic.uff.br');");
                int i = ps.executeUpdate();
                if (i > 0)
                    System.out.print("<h1>User registered...</h1>"); 
            */
            
            
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery(searchQuery);
            boolean more = rs.next();
            // if user does not exist set the isValid variable to false
            if (!more) {
                System.out.println("Sorry, you are not a registered user! Please sign up first");
                bean.setValid(false);
            } else if (more) {//if user exists set the isValid variable to true
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                cpf = rs.getString("cpf");
                senha = rs.getString("senha");
                senhaPIN = rs.getString("senhaPIN");
                int admin = rs.getInt("admin");
                int id = rs.getInt("id");
                String acesso = (String) rs.getTimestamp("acesso").toString();
                // TODO demais atributos

                System.out.println("Welcome " + nome);
                bean.setNome(nome);
                bean.setEmail(email);
                bean.setCPF(cpf);
                bean.setSenha(senha);
                bean.setAdmin(admin);
                bean.setID(id);
                bean.setAcesso(acesso);
                bean.setSenhaPIN(senhaPIN);
                bean.setValid(true);
            }
        } catch (Exception ex) {
            System.out.println("Login failed: An Exception has occurred! " + ex.getMessage());
        } finally { //some exception handling
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return bean;

    }
}
