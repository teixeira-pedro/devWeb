/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.uff.ic.projeto;

public class UserBean {

    private String cpf;
    private String senha;
    private String email;
    private String nome;
    private String acesso;
    private String senhaPIN;
    private int admin;
    private int id;
    public boolean valid;

    public int getAdmin() {
        return admin;
    }

    public void setAdmin(int newAdmin) {
        admin = newAdmin;
    }
    
    public int getID() {
        return id;
    }

    public void setID(int newID) {
        id = newID;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String newEmail) {
        email = newEmail;
    }
    public String getAcesso() {
        return acesso;
    }

    public void setAcesso(String newAcesso) {
        acesso = newAcesso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String newNome) {
        nome = newNome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String newSenha) {
        senha = newSenha;
    }

    public String getCPF() {
        return cpf;
    }

    public void setCPF(String newCPF) {
        cpf = newCPF;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean newValid) {
        valid = newValid;
    }
    
    @Override
    public String toString(){
        return "user: id="+id+ " cpf="+cpf+ " senha="+senha+ " senhaPIN="+senhaPIN+" email="+email+" nome="+nome+" valid="+valid+" admin="+admin+" acesso="+acesso;
    }

    void setSenhaPIN(String newSenhaPIN) {
        senhaPIN = newSenhaPIN; //To change body of generated methods, choose Tools | Templates.
    }

    String getSenhaPIN() {
        return senhaPIN; //To change body of generated methods, choose Tools | Templates.
    }
}
